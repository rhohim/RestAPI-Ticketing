const express = require('express')
require('dotenv').config()
const app = express()
const port = process.env.port

// for receive data from json raw postman
const bodyparser = require('body-parser')
app.use(bodyparser.json())

// call middleware
const MiddleAuth = require("./config/middleware")

// call router
const participanRoute = require("./routes/participan")
const eventRoute = require("./routes/event")
const userRouter = require('./routes/user')
// const ticketRoute = require("./routes/ticket")


// endpoint for route
app.use('/pasarkol/participan', MiddleAuth, participanRoute)
app.use('/pasarkol/event', MiddleAuth, eventRoute)
app.use('/pasarkol/login', MiddleAuth, userRouter)
// app.use('/pasarkol/ticket', MiddleAuth, ticketRoute)



// Sample in-memory database for demonstration purposes
const events = "welcome Dude!";

// GET all events (protected route)
app.get('/', (req, res) => {
    res.json(events);
});




app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})